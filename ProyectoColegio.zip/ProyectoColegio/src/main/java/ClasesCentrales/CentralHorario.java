/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClasesCentrales;

import Modelo.Horario;

/**
 *
 * @author cr075
 */
public class CentralHorario {
    public static Horario horarioActualizar;
}
